create definer = root@localhost view signalementparregion as
select `reg`.`IdRegion`                               AS `Id`,
       `reg`.`NomRegion`                              AS `Nom`,
       (select count(`sign`.`IdRegion`)
        from `cloud`.`signalementregion` `sign`
        where (`sign`.`IdRegion` = `reg`.`IdRegion`)) AS `Nombre`
from `cloud`.`region` `reg`;

