create view nonassigner as
select distinct `sig`.`IdSignalement`          AS `IdSignalement`,
                `sig`.`IdUtilisateur`          AS `IdUtilisateur`,
                `sig`.`IdType`                 AS `IdType`,
                `sig`.`IdStatus`               AS `IdStatus`,
                `sig`.`DescriptionSignalement` AS `DescriptionSignalement`,
                `sig`.`Longitude`              AS `Longitude`,
                `sig`.`Latitude`               AS `Latitude`,
                `sig`.`DateHeureSignalement`   AS `DateHeureSignalement`
from `cloud`.`signalement` `sig`
where (not (`sig`.`IdSignalement` in (select `sigr`.`IdSignalement` from `cloud`.`signaletregion` `sigr`)));

