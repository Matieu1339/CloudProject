create definer = root@localhost view signalementpartype as
select `typ`.`IdType`                                                                                             AS `Id`,
       `typ`.`NomType`                                                                                            AS `Nom`,
       (select count(`sign`.`IdType`)
        from `cloud`.`signalement` `sign`
        where (`sign`.`IdType` = `typ`.`IdType`))                                                                 AS `Nombre`
from `cloud`.`typesignalement` `typ`;

