create definer = root@localhost view signparetatregion as
select `reg`.`IdRegion`                                                                           AS `IdRegion`,
       `reg`.`NomRegion`                                                                          AS `NomRegion`,
       `statut`.`IdStatus`                                                                        AS `IdStatus`,
       `statut`.`NomStatus`                                                                       AS `NomStatus`,
       (select count(0)
        from `cloud`.`signaletregion` `sr`
        where ((`sr`.`IdStatus` = `statut`.`IdStatus`) and (`sr`.`IdRegion` = `reg`.`IdRegion`))) AS `nombre`
from `cloud`.`region` `reg`
         join `cloud`.`statussignalement` `statut`;

