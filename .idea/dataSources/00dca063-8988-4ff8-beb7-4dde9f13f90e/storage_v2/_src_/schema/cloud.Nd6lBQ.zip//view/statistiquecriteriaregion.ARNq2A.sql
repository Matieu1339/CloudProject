create definer = root@localhost view statistiquecriteriaregion as
select `signaletregion`.`IdSignalement`          AS `IdSignalement`,
       `signaletregion`.`IdUtilisateur`          AS `IdUtilisateur`,
       `signaletregion`.`IdType`                 AS `IdType`,
       `signaletregion`.`IdStatus`               AS `IdStatus`,
       `signaletregion`.`DescriptionSignalement` AS `DescriptionSignalement`,
       `signaletregion`.`Longitude`              AS `Longitude`,
       `signaletregion`.`Latitude`               AS `Latitude`,
       `signaletregion`.`DateHeureSignalement`   AS `DateHeureSignalement`,
       `signaletregion`.`IdRegion`               AS `IdRegion`,
       `signaletregion`.`NomRegion`              AS `NomRegion`,
       count(`signaletregion`.`IdSignalement`)   AS `Nombre`
from `cloud`.`signaletregion`
group by `signaletregion`.`IdRegion`;

