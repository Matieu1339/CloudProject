create definer = root@localhost view signpartyperegion as
select `reg`.`IdRegion`                                                                    AS `IdRegion`,
       `reg`.`NomRegion`                                                                   AS `NomRegion`,
       `typ`.`IdType`                                                                      AS `IdType`,
       `typ`.`NomType`                                                                     AS `NomType`,
       `typ`.`Couleur`                                                                     AS `Couleur`,
       (select count(0)
        from `cloud`.`signaletregion` `sr`
        where ((`sr`.`IdType` = `typ`.`IdType`) and (`sr`.`IdRegion` = `reg`.`IdRegion`))) AS `nombre`
from `cloud`.`region` `reg`
         join `cloud`.`typesignalement` `typ`;

