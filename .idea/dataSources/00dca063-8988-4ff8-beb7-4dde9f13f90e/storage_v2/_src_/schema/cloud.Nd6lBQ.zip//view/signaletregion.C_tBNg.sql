create definer = root@localhost view signaletregion as
select distinct `sig`.`IdSignalement`          AS `IdSignalement`,
                `sig`.`IdUtilisateur`          AS `IdUtilisateur`,
                `sig`.`IdType`                 AS `IdType`,
                `sig`.`IdStatus`               AS `IdStatus`,
                `sig`.`DescriptionSignalement` AS `DescriptionSignalement`,
                `sig`.`Longitude`              AS `Longitude`,
                `sig`.`Latitude`               AS `Latitude`,
                `sig`.`DateHeureSignalement`   AS `DateHeureSignalement`,
                `sigr`.`IdRegion`              AS `IdRegion`,
                `cloud`.`region`.`NomRegion`   AS `NomRegion`
from ((`cloud`.`signalement` `sig` join `cloud`.`signalementregion` `sigr` on ((`sig`.`IdSignalement` = `sigr`.`IdSignalement`)))
         join `cloud`.`region` on ((`sigr`.`IdRegion` = `cloud`.`region`.`IdRegion`)))
group by `sig`.`IdSignalement`, `sigr`.`IdRegion`;

