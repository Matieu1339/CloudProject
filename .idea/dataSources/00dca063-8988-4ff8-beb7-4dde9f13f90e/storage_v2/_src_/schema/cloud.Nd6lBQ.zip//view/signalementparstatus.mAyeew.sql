create definer = root@localhost view signalementparstatus as
select `status`.`IdStatus`                               AS `Id`,
       `status`.`NomStatus`                              AS `Nom`,
       (select count(`sign`.`IdSignalement`)
        from `cloud`.`signalement` `sign`
        where (`sign`.`IdStatus` = `status`.`IdStatus`)) AS `Nombre`
from `cloud`.`statussignalement` `status`;

